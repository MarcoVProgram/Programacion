public enum Genero {
    ROMANCE,
    TERROR,
    FANTASIA,
    COMEDIA,
    ACCION
}