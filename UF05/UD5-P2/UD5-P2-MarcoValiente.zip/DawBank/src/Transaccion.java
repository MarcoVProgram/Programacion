public enum Transaccion {
    INGRESO,
    RETIRADA
}
