public class CuentaException extends Exception {

    private static final long serialVersionUID = 2150583975754627932L;

    public CuentaException(String message) {
        super(message);
    }
}
